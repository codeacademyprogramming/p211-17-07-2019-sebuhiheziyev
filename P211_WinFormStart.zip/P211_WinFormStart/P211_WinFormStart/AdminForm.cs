﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P211_WinFormStart
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            //Load produts
            Product[] products = ProductList.GetProducts();

            foreach (Product product in products)
            {
                lbProducts.Items.Add(product.Name);
            }

            //Load categories
            Category[] categories = CategoryList.GetCategories();

            foreach (Category category in categories)
            {
                cmbCategories.Items.Add(category.Name);
            }
        }
    }
}
