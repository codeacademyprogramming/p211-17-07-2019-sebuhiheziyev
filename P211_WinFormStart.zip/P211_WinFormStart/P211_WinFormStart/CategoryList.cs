﻿namespace P211_WinFormStart
{
    public static class CategoryList
    {
        private static Category[] categories = new Category[3]
        {
            new Category { Name = "Dairy Products" },
            new Category { Name = "Meat Products" },
            new Category { Name = "Bakery Products" }
        };

        public static Category[] GetCategories() => categories;
    }
}
