﻿namespace P211_WinFormStart
{
    public class Category
    {
        private static int _counter = 1;

        public string Id { get; private set; }
        public string Name { get; set; }

        public Category()
        {
            #region Dynamic id generator Way 1
            //if(_counter.ToString().Length == 1)
            // {
            //     Id = "0000" + _counter;
            // }
            // if (_counter.ToString().Length == 2)
            // {
            //     Id = "000" + _counter;
            // }
            // if (_counter.ToString().Length == 3)
            // {
            //     Id = "00" + _counter;
            // }
            // if (_counter.ToString().Length == 4)
            // {
            //     Id = "0" + _counter;
            // }
            // else
            // {
            //     Id = _counter.ToString();
            // }
            #endregion

            #region Dynamic id generator Main
            Id = new string('0', 5 - _counter.ToString().Length) + _counter.ToString();
            _counter++;
            #endregion
        }
    }
}
